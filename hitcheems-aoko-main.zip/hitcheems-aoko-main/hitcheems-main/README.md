# hitcheems
 Hit Cheems <br>
My Youtube: https://www.youtube.com/c/minkalexvina/ <br>
My Facebook: https://www.facebook.com/minkalexvina/ <br>
My Instagram: https://www.instagram.com/minkalexvina/ <br>
Group Dân IT (only for VN people): https://www.facebook.com/groups/803129063825326/ <br>
All about me: http://iz.ag/minkalexvina/ <br>
